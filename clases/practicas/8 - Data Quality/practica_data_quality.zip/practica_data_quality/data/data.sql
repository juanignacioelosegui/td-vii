COPY turnstiles7(
    FECHA,
    DESDE,
    HASTA,
    LINEA,
    MOLINETE,
    ESTACION,
    pax_pagos,
    pax_pases_pagos,
    pax_franq,
    pax_TOTAL
)
FROM '/data/2021-01.csv'
DELIMITER ','
CSV HEADER
ENCODING 'LATIN1';